clear all;
close all;
 

R=10;
R1=10;
R2=5;
E1p=15;
E1m=-15;
E2p=15;
E2m=-15;
E3p=15;
E3m=-15;
X=1;
Y=1;
A1=1;
A2=2;
f=50;
N=4;

circ(R,R1,R2,E1p,E1m,E2p,E2m,E3p,E3m,X,Y,A1,A2,f,N);